<?php

include("include/mysql.php");

$db = new myConnection;

return $db->signout();